=== consultx ===
Contributors: rozerben
Tags: blog, two-columns, right-sidebar, full-width-template, custom-colors, custom-menu, custom-header, custom-logo, featured-images, editor-style, custom-background, threaded-comments, theme-options, translation-ready

Requires at least: 4.0
Tested up to: 5.2
Version: 1.0
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
ConsultX is free WordPress theme. It can be use for any type of firm or a company. 

== Theme License & Copyright ==
* consultx WordPress Theme, Copyright 2019, rozerben
* consultx is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

== Resources ==

Theme is Built using the following resource bundles.

1 - All js/css that have been used are within folder /js or /css of theme.

2 - jQuery Owl Carousel Slider
	Owl Carousel v2.2.1
 	* Copyright 2013-2017 David Deutsch
 	* Licensed under MIT

3 -	* imagesLoaded PACKAGED v4.1.1
 	* JavaScript is all like "You images are done yet or what?"
 	* MIT License

4 -	* Isotope PACKAGED v3.0.1
	 *
	 * Licensed GPLv3 for open source use
	 * or Isotope Commercial License for commercial use
	 *
	 * http://isotope.metafizzy.co
	 * Copyright 2016 Metafizzy

5 -	* SlickNav Responsive Mobile Menu v1.0.10
	* (c) 2016 Josh Cope
	* licensed under MIT

6 -	 * Lightbox v2.10.0
	 * by Lokesh Dhakar
	 *
	 * More info:
	 * http://lokeshdhakar.com/projects/lightbox2/
	 *
	 * Copyright 2007, 2018 Lokesh Dhakar
	 * Released under the MIT license
	 * https://github.com/lokesh/lightbox2/blob/master/LICENSE

7 -	* https://github.com/kenwheeler/slick/blob/master/LICENSE

8.- * animate
    * (c) 2013 Daniel Eden
    * http://daneden.me/animate
    * licensed under MIT


9.- Montserrat Font, through Google Font,
	https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700|Open+Sans:300,400,600  

10 - Images used from pxhere.com and stocksnap.io
  	License-:
    (https://pxhere.com/en/license)
    (https://stocksnap.io/license)

    Images:	
    Screenshot: 
       https://stocksnap.io/photo/NWXA46JA4V
	   https://pxhere.com/en/photo/649367
	   https://pxhere.com/en/photo/762427
	   https://pxhere.com/en/photo/689275
	   https://pxhere.com/en/photo/625568       


11 - Font Awesome - https://fontawesome.com
    Font License:
    ======
	Applies to all desktop and webfont files in the following directory: font-awesome/fonts/.
	License: SIL OFL 1.1
	URL: http://scripts.sil.org/OFL

	Code License:
    ===========
	Applies to all CSS and Js files in the following directories: assets/css/, assets/Js/.
	License: MIT License
	URL: http://opensource.org/licenses/mit-license.html
       